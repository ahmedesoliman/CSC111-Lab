// Question1: write a C++ program that print out your information in separate lines.

// Hint: your information is like following:

// Name:...

// family name:...

// Major:...

// Address:...

#include <iostream>
using namespace std;

int main()
{
    cout << "First Name: Ahmed" << endl;
    cout << "Last Name: Soliman" << endl;
    cout << "Major: Computer Science\n"
         << "Address: Staten Island, NY";
    return 0;
}